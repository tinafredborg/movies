<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="utf-8">
        <link href="crud/css/bootstrap.min.css" rel="stylesheet">
        <script src="crud/js/bootstrap.min.js"></script>
    </head>

<body>
<div class="container">
        <div class="row">
                <h3>Product Information</h3>
            </div>

        <div class="row">
                <p>
                        <a href="crud/create.php" class="btn btn-success">Create</a>
                    </p>

                <table class="table table-striped table-bordered">
                        <thead>
                        <tr>
                                <th>ID</th>
                                <th>title</th>

                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        include '../include/dbh.php';
                        $pdo = Database::connect();
                        $sql = 'SELECT * FROM film ORDER BY id DESC';
                        foreach ($pdo->query($sql) as $row) {
                                echo '<tr>';
                 echo '<td>'. $row['id'] . '</td>';
                 echo '<td>'. $row['title'] . '</td>';

                 echo '<td width=250>';
                 echo '<a class="btn" href="crud/read.php?id='.$row['id'].'">Read</a>';
                 echo '&nbsp;';
                 echo '<a class="btn btn-success" href="crud/update.php?id='.$row['id'].'">Update</a>';
                 echo '&nbsp;';
                 echo '<a class="btn btn-danger" href="crud/delete.php?id='.$row['id'].'">Delete</a>';
                 echo '</td>';
                echo '</tr>';
             }
             ?>
                        </tbody>
                    </table>
                <p>
                        <a class="btn" href="admin.php">back</a>
                    </p>
            </div>
    </div> <!-- /container -->
</body>
</html>