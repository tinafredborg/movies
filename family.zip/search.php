<?php
//files to be included
require_once "includes.php";

?>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <title>the movie theater</title>
    <meta charset = "utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.php">
    <script async="" type="text/javascript" src="http://www.googletagservices.com/tag/js/gpt.js"></script>
    <!-- JAVASCRIPT to clear search text when the field is clicked -->
    <script type="text/javascript">
        $(function() {
            $("#searchBar").click(function() {
                if ($("#searchBar").val() == "search movie"){
                    d     $("#searchBar").val("");
                }
            });
        });
    </script>
</head>
<body class="body">
<header>
    <div class="flex-container">
        <?php include 'include/menu.php'; ?>
    </div>
</header>
<div class="wrapper">
    <article class="main">
        <aside class="aside aside-1">
            <?php include 'include/genre.php'; ?>
        </aside>
     <div class="movie">
        <div class="content">
            <h1 class="virksomhed">Search result</h1>
            <table border="1">

                <?php

                if(isset($_POST['search'])) {
                    GetSearchResult($_POST['search']);
                }

                ?>

            </table>
        </div>
     </div>
    </article>
   </div>
<footer class="footer">
    <p class="footer">the movie theater</p>
</footer>
</body>
</html>