<div>

<div class="box logo">

    <h1 class="overskrift">the movie theater</h1>
</div>
<div class="box chart">

    <a class="login" href="admin_login/login.php" >Admin Log in</a>
</div>
<div class="box menu">
    <div class="navbar">
        <ul class="nav">
            <li><a href="movie.php">Home</a></li>
            <li><a href="sider/about.php">Om os</a></li>
            <li><a href="sider/contact.php">Kontakt os</a></li>
        </ul>
    </div>

    <!-- HTML for SEARCH BAR -->
    <div id="tfheader">
        <form action="search.php" method="post">
            <input type="text" id="searchBar" name="search" placeholder="search movie" size="21" maxlength="120" value="search movie" />
            <input type="submit" id="searchbtn" name="submit" value=">>" />
        </form>
        <div class="tfclear"></div>
    </div>
</div>
