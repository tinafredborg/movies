<!DOCTYPE html>
<?php
//files to be included
require_once "includes.php";

?>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <title>the movie theater</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.php">
    <script async="" type="text/javascript" src="http://www.googletagservices.com/tag/js/gpt.js"></script>
    <!-- JAVASCRIPT to clear search text when the field is clicked -->
    <script type="text/javascript">
        $(function () {
            $("#searchBar").click(function () {
                if ($("#searchBar").val() == "search movie") {
                    $("#searchBar").val("");
                }
            });
        });
    </script>
</head>
<body class="body">
<header>
    <div class="flex-container">
        <?php include 'include/menu.php'; ?>
    </div>
</header>
<div class="wrapper">
    <article class="main">
        <aside class="aside aside-1">
            <?php include 'include/genre.php'; ?>
        </aside>
     <div class="movie">
        <div class="content">
            <h1 class="product">our movies</h1>
        </div>
        <?php
        try {
            $conn = Database::connect();
            $stmt = $conn->prepare("SELECT DISTINCT film.id, film.title, film.price, film.photo
            FROM genre JOIN film ON genre.filmId = film.id
            JOIN filmgenre ON genre. filmgenreID = filmgenre.id WHERE filmgenre.id LIKE 1");
            $stmt->execute();
            $movie = $stmt->fetchAll(); // Hent alle products fra databasen og gem dem i et array ($pro).

        }//ProID, Name, Pris, Photos
        catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
        GeneratemovieGrid($movie)
        ?>
     </div>
    </article>
</div>
<footer class="footer">
    <p class="footer"> the movie theater</p>
</footer>
</body>
</html>

