<?php
    header("Content-type: text/css; charset: UTF-8");
?>

.body {background-color: paleturquoise;
    padding: 2em;
}

.wrapper{width: 100%;
    margin: 0 auto;
}
.flex-container{display: flex;
    flex-flow: column;
}
/*header*/
.login {text-decoration: none;
    margin-right: 2%;
    float: right;
    margin-top: 1%;
}

.box{background-color: white;
    height: 50px;
    width: 100%;
}
.overskrift{
    font-family: "MV Boli";
    font-size: 32px;
    color: darkorange;
    margin-top: -42px;
    margin-left: 50px;
}
/*searchform*/
#searchBar{ border: 1px solid darkorange;
    font-size: 16px;
    padding: 2px;
    outline: none;
    width: 200px;
    border-right: none;
    border-bottom-left-radius: 10px;
    border-top-left-radius: 10px;
    float: right;
    margin-right: 3.5%;
}
#searchbtn{ border: 1px solid darkorange;
    font-size: 16px;
    padding: 2px;
    font-weight: bold;
    outline: none;
    cursor: pointer;
    background-color: darkorange;
    border-bottom-right-radius: 10px;
    border-top-right-radius: 10px;
    float: right;
    margin-right:12px;
    width: 28px;
    height: 28px;
}
#searchbtn:hover{background: paleturquoise;
    border-color: paleturquoise;
}
.tfclear{
    clear:both;
}
/*navigation*/
.navbar {float: left;

}
.navbar li {display: inline-block;
           padding: 5px;

}
.navbar ul {overflow: hidden;
}
li a {text-decoration: none;

}
.menu{ border-bottom: solid paleturquoise;

}
ul li  {list-style: none;}
@media Screen and (max-width: 480px){
.navbar ul li{
    float: none;
    border-bottom: solid 1px darkorange;
}
}
.slider {background-color: white;
    border-bottom: solid paleturquoise;
}
/*body styles*/

#virksomhed {color: darkorange;
    background-color: white;
    font-size: 30px;
}
.nyheder {
    border-bottom: solid paleturquoise;
}
.tilbud {
    margin-right: 4%;
    background-color: white;
}
.hojre {float: right;
    margin-top: 0%;
}
.h2hojre {float: right;
          margin-top: -7%;
}
 #feed h3{
    font-size: 20px;
     color: darkorange;
}
footer { border-bottom: solid paleturquoise;
    background-color: white;
    color: darkorange;
    height: 18px;
   }
.wrapper {
    display: -webkit-box;
    display: -moz-box;
    display: -ms-flexbox;
    display: -webkit-flex;
    display: flex;
    -webkit-flex-flow: row wrap;
    flex-flow: row wrap;
    font-weight: bold;
}
.wrapper > * {
    padding: 10px;
    flex: 1 100%;
}

.main { flex-grow: 4;
    text-align: left;
    background: white;
}
.aside ul li  {color: darkblue;
;
}

.aside-1 { flex-grow: 1;
    background: white;
    border-right: solid paleturquoise;
    width: 5%;

}

.container {
    width: 306px;
    max-width: 306px;
    margin: 0 auto;
}

.header h3 {
    color: darkorange;
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 5px;
    margin-left: -24%;
}
h3 {
    color: darkorange;
    font-weight: bold;
}

.besked{margin-left: -24%;
        color: darkorange;
}


.photo {
	max-width: 200px;
}