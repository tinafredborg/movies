<?php

require '../../include/dbh.php';
$id = null;
if ( !empty($_GET['id'])) {
    $id = $_REQUEST['id'];
}
if ( null==$id ) {
    header("Location: ../managemovie.php");
}
if ( !empty($_POST)) {
    // keep track validation errors
    $titleError = null;
    $descriptionError = null;
    $priceError = null;
    $photosError = null;
    $genreIdError = null;
    // keep track post values
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $photos = $_POST['photo'];
    $genreId = $_POST['genreId'];
    // validate input
    $valid = true;
    if (empty($name)) {
        $titleError = 'Please enter Title';
        $valid = false;
    }
    if (empty($description)) {
        $descriptionError = 'Please enter description';
        $valid = false;
    }
    if (empty($price)) {
        $priceError = 'Please enter Price';
        $valid = false;
    }
    if (empty($photo)) {
        $photosError = 'Please enter Photo';
        $valid = false;
    }
    if (empty($genreId)) {
        $genreIdError = 'Please enter genre ID';
        $valid = false;
    }

 		// update data
 		if ($valid) {
        			$pdo = Database::connect();
        			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        			$sql = "UPDATE film  set title = ?, description = ?, Price = ?, photo = ?, genreId = ? WHERE id = ?";
        			$q = $pdo->prepare($sql);
        			$q->execute(array($title,$description,$price,$photos,$genreId,$id));
        			Database::disconnect();
        		header("Location: ../managemovie.php");
        		}
 	} else {
    		$pdo = Database::connect();
    		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    		$sql = "SELECT * FROM film where id = ?";
    		$q = $pdo->prepare($sql);
    		$q->execute(array($id));
    		$data = $q->fetch(PDO::FETCH_ASSOC);
    		$title = $data['title'];
    		$description = $data['description'];
    		$price = $data['price'];
            $photos = $data['photo'];
            $genreId = $data['genreId'];
    		Database::disconnect();
    	}
 ?>


<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="utf-8">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <script src="js/bootstrap.min.js"></script>
    </head>

<body>
    <div class="container">

        			<div class="span10 offset1">
            				<div class="row">
            		    			<h3>Update a movie</h3>
            		    		</div>

        	    			<form class="form-horizontal" action="update.php?id=<?php echo $id?>" method="post">
            					  <div class="control-group <?php echo !empty($titleError)?'error':'';?>">
                					    <label class="control-label">Title</label>
                					    <div class="controls">
                    					      	<input name="title" type="text"  placeholder="Title" value="<?php echo !empty($title)?$title:'';?>">
                    					      	<?php if (!empty($titleError)): ?>
                        				      		<span class="help-inline"><?php echo $titleError;?></span>
                        					      	<?php endif; ?>
                    					    </div>
                					  </div>
                                    <div class="control-group <?php echo !empty($descriptionError)?'error':'';?>">
                                            <label class="control-label">Film description</label>
                                            <div class="controls">
                                                    <input name="description" type="text" placeholder="description" value="<?php echo !empty($description)?$description:'';?>">
                                                    <?php if (!empty($descriptionError)): ?>
                                                            <span class="help-inline"><?php echo $descriptionError;?></span>
                                                        <?php endif;?>
                                                </div>
                                        </div>
                                    <div class="control-group <?php echo !empty($priceError)?'error':'';?>">
                                            <label class="control-label">Price</label>
                                            <div class="controls">
                                                    <input name="price" type="text"  placeholder="Price" value="<?php echo !empty($price)?$price:'';?>">
                                                    <?php if (!empty($priceError)): ?>
                                                            <span class="help-inline"><?php echo $priceError;?></span>
                                                        <?php endif;?>
                                                </div>
                                        </div>

                                    <div class="control-group <?php echo !empty($photosError)?'error':'';?>">
                                            <label class="control-label">Photo</label>
                                            <div class="controls">
                                                    <input name="photo" type="text"  placeholder="Photo" value="<?php echo !empty($photos)?$photos:'';?>">
                                                    <?php if (!empty($photosError)): ?>
                                                            <span class="help-inline"><?php echo $photosError;?></span>
                                                        <?php endif;?>
                                                </div>
                                        </div>

                                    <div class="control-group <?php echo !empty($genreIdError)?'error':'';?>">
                                            <label class="control-label">genre ID</label>
                                            <div class="controls">
                                                    <input name="genreId" type="text"  placeholder="genreID" value="<?php echo !empty($genreId)?$genreId:'';?>">
                                                   <?php if (!empty($genreIdError)): ?>
                                                            <span class="help-inline"><?php echo $genreIdError;?></span>
                                                        <?php endif;?>
                                                </div>
                                        </div>
            					  <div class="form-actions">
                						  <button type="submit" class="btn btn-success">Update</button>
                						  <a class="btn" href="../managemovie.php">Back</a>
                						</div>
            				</form>
        				</div>

        </div> <!-- /container -->
  </body>
</html>