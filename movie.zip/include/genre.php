
<html>
        <h3>movie genre</h3>
        <ul>
            <li><a href="science.php">sciencefiction</a></li>
            <li><a href="romantic.php">romantic</a></li>
            <li><a href="family.php">family</a></li>
            <li><a href="action.php">action</a></li>
            <li><a href="movie.php">our movies</a></li>
        </ul>
</html>